﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace alprotikum.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "penyewas",
                columns: table => new
                {
                    NoPenyewa = table.Column<string>(type: "varchar(200)", nullable: false),
                    Nama = table.Column<string>(type: "varchar(200)", nullable: true),
                    NoKTP = table.Column<string>(type: "varchar(200)", nullable: true),
                    alamat = table.Column<string>(type: "varchar(200)", nullable: true),
                    NoTelp = table.Column<string>(type: "varchar(200)", nullable: true),
                    pekerjaan = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_penyewas", x => x.NoPenyewa);
                });

            migrationBuilder.CreateTable(
                name: "transaksis",
                columns: table => new
                {
                    NoTransaksi = table.Column<string>(type: "varchar(200)", nullable: false),
                    Tanggal = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NoPenyewa = table.Column<string>(type: "varchar(200)", nullable: true),
                    MobilId = table.Column<string>(type: "varchar(200)", nullable: true),
                    WaktuSewa = table.Column<string>(type: "varchar(200)", nullable: true),
                    UangMuka = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_transaksis", x => x.NoTransaksi);
                    table.ForeignKey(
                        name: "FK_transaksis_penyewas_NoPenyewa",
                        column: x => x.NoPenyewa,
                        principalTable: "penyewas",
                        principalColumn: "NoPenyewa",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "mobils",
                columns: table => new
                {
                    MobilId = table.Column<string>(type: "varchar(200)", nullable: false),
                    NoPolisi = table.Column<string>(type: "varchar(200)", nullable: true),
                    JenisMobil = table.Column<string>(type: "varchar(200)", nullable: true),
                    HargaMobil = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mobils", x => x.MobilId);
                    table.ForeignKey(
                        name: "FK_mobils_transaksis_MobilId",
                        column: x => x.MobilId,
                        principalTable: "transaksis",
                        principalColumn: "NoTransaksi",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_transaksis_NoPenyewa",
                table: "transaksis",
                column: "NoPenyewa");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "mobils");

            migrationBuilder.DropTable(
                name: "transaksis");

            migrationBuilder.DropTable(
                name: "penyewas");
        }
    }
}
