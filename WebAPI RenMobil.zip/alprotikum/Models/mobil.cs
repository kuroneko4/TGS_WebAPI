using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace renMobil.Models
{
   public class mobil
{
    [ForeignKey("transaksi")]
    [Column(TypeName ="varchar(200)")]
    public string MobilId { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string NoPolisi { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string JenisMobil { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string HargaMobil { get; set; }

    public virtual transaksi transaksi { get; set; }
}    
}