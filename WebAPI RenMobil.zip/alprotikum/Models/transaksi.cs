using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System;

namespace renMobil.Models
{
    public class transaksi
    {
    [Key]
    [Column(TypeName ="varchar(200)")]
    public string NoTransaksi { get; set; }

    public DateTime Tanggal { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string NoPenyewa { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string MobilId { get; set; }
    
    [Column(TypeName ="varchar(200)")]
    public string WaktuSewa { get; set; }
    
    [Column(TypeName ="varchar(200)")]
    public string UangMuka { get; set; }

    public virtual mobil mobil { get; set; }
}  
}