using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace renMobil.Models
{
  public class penyewa
{
    [Key]
    [Column(TypeName ="varchar(200)")]
    public string NoPenyewa { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string Nama { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string NoKTP { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string alamat { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string NoTelp { get; set; }

    [Column(TypeName ="varchar(200)")]
    public string pekerjaan { get; set; }

    [ForeignKey("NoPenyewa")]
    public ICollection<transaksi> transaksis { get; set; }
}  
}