using Microsoft.EntityFrameworkCore;

namespace renMobil.Models
{
    public class MobilContext : DbContext
    {
        public MobilContext(DbContextOptions<MobilContext> options)
            : base(options)
        {
        }

        public DbSet<penyewa> penyewas { get; set; }
        public DbSet<transaksi> transaksis { get; set; }
        public DbSet<mobil> mobils { get; set; }
    
    }
}